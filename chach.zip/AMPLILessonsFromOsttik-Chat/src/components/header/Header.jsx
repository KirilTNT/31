import './styles.css';

export default function Header(props) {
    return (
        <div className="chatHeader">
            <div className="chatText">
                My Chat
            </div>
            <div>
                <input />
            </div>
        </div>
    )
}